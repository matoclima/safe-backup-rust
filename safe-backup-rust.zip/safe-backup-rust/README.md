# SafeBackup – Secure Rust File Backup Tool

This project implements a secure file backup, restore, and delete tool in Rust.  
It follows best practices for safe file handling, input validation, and logging.

---

## 🔗 GitHub Repository Link

👉 [INSERT YOUR REPOSITORY LINK HERE]

---

## 🛠️ How to Compile

Make sure you have Rust installed.  
To compile the program, run:

```bash
rustc safe_backup.rs
```

This will generate an executable named `safe_backup`.

---

## ▶️ How to Run

To run the compiled program:

```bash
./safe_backup
```

You will then be prompted with:

```
Enter file name: sample.txt
Enter command (backup, restore, delete): backup
```

If the file exists, a backup file called `sample.txt.bak` will be created.

---

## 🧪 How to Test

1. Create a text file, e.g., `sample.txt` with some content:

    ```
    Hello, this is a test file!
    ```

2. Run the program with the command `backup`, `restore`, or `delete`.

3. Example commands:

    ```bash
    ./safe_backup
    Enter file name: sample.txt
    Enter command (backup, restore, delete): backup
    ```

4. Check that:

    - A `.bak` file is created on backup
    - Original file is replaced on restore
    - File is removed on delete (after confirmation)

---

## 🔐 Secure Design Decisions

- **Input validation**: All filenames are checked using a strict regex (`^[\w\-.]+$`) to prevent directory traversal.
- **Safe I/O handling**: Uses `BufReader` and checks for file existence before reading or writing.
- **Confirmation step** before file deletion to avoid accidental loss.
- **Action logging**: All user actions are written to a log file (`logfile.txt`).
- **No unsafe code**: Fully implemented using Rust’s standard safe abstractions.

---

## 🖼️ Screenshots

See the `/screenshots/` folder or the attached PDF report.

---

## 📚 References

- [Rust Book](https://doc.rust-lang.org/book/)
- [OWASP Secure Coding Practices](https://owasp.org/www-project-secure-coding-practices/)
- Rust `std::fs`, `regex`, `io` documentation