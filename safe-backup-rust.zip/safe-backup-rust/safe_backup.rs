use std::fs::{self, File, OpenOptions};
use std::io::{self, BufRead, BufReader, Write};
use std::path::Path;
use regex::Regex;

fn validate_filename(name: &str) -> bool {
    let re = Regex::new(r"^[\w\-.]+$").unwrap();
    re.is_match(name)
}

fn backup_file(filename: &str) {
    let input = File::open(filename);
    if input.is_err() {
        eprintln!("Error: cannot open file for backup.");
        return;
    }

    let reader = BufReader::new(input.unwrap());
    let backup_name = format!("{}.bak", filename);

    let output = File::create(&backup_name);
    if output.is_err() {
        eprintln!("Error: cannot create backup file.");
        return;
    }

    let mut writer = output.unwrap();
    for line in reader.lines() {
        if let Ok(content) = line {
            writeln!(writer, "{}", content).unwrap();
        }
    }

    println!("Backup created: {}", backup_name);
    log_action("Performed backup");
}

fn restore_file(filename: &str) {
    let backup_name = format!("{}.bak", filename);
    let input = File::open(&backup_name);
    if input.is_err() {
        eprintln!("Error: backup file not found.");
        return;
    }

    let reader = BufReader::new(input.unwrap());
    let output = File::create(filename);
    if output.is_err() {
        eprintln!("Error: cannot restore original file.");
        return;
    }

    let mut writer = output.unwrap();
    for line in reader.lines() {
        if let Ok(content) = line {
            writeln!(writer, "{}", content).unwrap();
        }
    }

    println!("File restored from: {}", backup_name);
    log_action("Performed restore");
}

fn delete_file(filename: &str) {
    println!("Are you sure you want to delete {}? (yes/no):", filename);
    let mut confirm = String::new();
    io::stdin().read_line(&mut confirm).unwrap();
    let confirm = confirm.trim().to_lowercase();

    if confirm == "yes" {
        match fs::remove_file(filename) {
            Ok(_) => println!("File deleted."),
            Err(_) => eprintln!("Error: unable to delete file."),
        }
        log_action("Performed delete");
    } else {
        println!("Delete operation cancelled.");
    }
}

fn log_action(action: &str) {
    let mut file = OpenOptions::new()
        .create(true)
        .append(true)
        .open("logfile.txt")
        .unwrap();
    writeln!(file, "{}", action).unwrap();
}

fn main() {
    let mut filename = String::new();
    println!("Enter file name:");
    io::stdin().read_line(&mut filename).unwrap();
    let filename = filename.trim();

    if !validate_filename(filename) {
        eprintln!("Invalid filename.");
        return;
    }

    let mut command = String::new();
    println!("Enter command (backup, restore, delete):");
    io::stdin().read_line(&mut command).unwrap();
    let command = command.trim();

    match command {
        "backup" => backup_file(filename),
        "restore" => restore_file(filename),
        "delete" => delete_file(filename),
        _ => eprintln!("Unknown command."),
    }
}